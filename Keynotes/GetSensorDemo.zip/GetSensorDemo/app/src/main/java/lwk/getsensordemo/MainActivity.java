package lwk.getsensordemo;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private SensorManager sensorManager;
    private SensorEventListener listener;
    private Sensor AccelerometerSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView)findViewById(R.id.textview);

        //通过getSystemServiceu获取传感器句柄
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);

        //获取默认的加速度传感器
        AccelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        //获取压力传感器列表
        List<Sensor> pressureSensors = sensorManager.getSensorList(Sensor.TYPE_PRESSURE);

        //获取所有传感器
        List<Sensor> allSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                //当传感器数值变化时调用
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
                //当传感器精度变化时调用
            }
        };


        for(Sensor sensor:allSensors){
            textView.append(sensor.getName() + '\n');
        }
    }

    public void onResume(){
        super.onResume();
        //注册监听器
        sensorManager.registerListener(listener,AccelerometerSensor,SensorManager.SENSOR_DELAY_UI);
        //SENSOR_DELAY_UI:适合普通用户界面UI变化的频率
    }
    public void onPause(){
        super.onPause();
        sensorManager.unregisterListener(listener);
    }
}

