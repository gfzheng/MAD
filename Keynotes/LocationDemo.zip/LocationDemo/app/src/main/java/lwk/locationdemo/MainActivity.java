package lwk.locationdemo;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private TextView longitude;
    private TextView latitude;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private double lat;
    private double lon;


    private static void checkPermission(Context context, String permission){
        int perm = context.checkCallingOrSelfPermission(permission);
        String[] permissions = { permission };
        if(perm != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions((Activity)context, permissions,1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "权限获取成功", Toast.LENGTH_SHORT).show();
        } else {
            // 权限被用户拒绝了关闭界面。
            System.exit(0);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        checkPermission(this,"android.permission.ACCESS_FINE_LOCATION");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        longitude = (TextView)findViewById(R.id.longitude);
        latitude = (TextView)findViewById(R.id.latitude);

        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE); //获取系统服务


    }
    @Override
    protected void onResume() {
        super.onResume();

        checkPermission(this,"android.permission.ACCESS_FINE_LOCATION");
        final String provider = LocationManager.GPS_PROVIDER;       //定义定位方法为GPS

        //获取缓存位置信息
        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        //模拟器会返回null
//        lat = lastKnownLocation.getLatitude();
//        lon = lastKnownLocation.getLongitude();
//        latitude.setText("纬度： " + Double.toString(lat));
//        longitude.setText("经度： " + Double.toString(lon));

        //定义回调函数
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                //在设备的位置改变时调用
                lat = location.getLatitude();
                lon = location.getLongitude();
                latitude.setText("纬度： " + Double.toString(lat));
                longitude.setText("经度： " + Double.toString(lon));
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                //在提供定位功能的硬件的状态改变时调用
            }

            @Override
            public void onProviderEnabled(String provider) {
                //在用户启用具有定位功能的硬件时被调用
            }

            @Override
            public void onProviderDisabled(String provider) {
                //在用户禁用具有定位功能的硬件时调用
            }
        };

        //设置时间变化频率
        locationManager.requestLocationUpdates(provider,2000,10,locationListener);
    }
    @Override
    protected void onPause() {
        super.onPause();
        // 移除监听器
        locationManager.removeUpdates(locationListener);
    }

}
